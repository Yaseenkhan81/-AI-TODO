import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { TaskProvider } from './contexts/TaskContext';
import { ThemeProvider } from './contexts/ThemeContext';
import Header from './components/Header';
import TaskBoard from './components/TaskBoard';
import AIAssistant from './components/AIAssistant';
import TaskStats from './components/TaskStats';
import LoginForm from './components/LoginForm';
import './App.css';

const AppContent: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setTimeout(() => setIsLoaded(true), 100);
  }, []);

  if (isLoading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  return (
    <TaskProvider>
      <div className={`app-container ${isLoaded ? 'loaded' : ''}`}>
        <div className="app-background"></div>
        <Header />
        <main className="main-content">
          <div className="content-grid">
            <div className="left-panel">
              <TaskStats />
              <AIAssistant />
            </div>
            <div className="center-panel">
              <TaskBoard />
            </div>
          </div>
        </main>
      </div>
    </TaskProvider>
  );
};

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;