interface TaskSuggestion {
  description: string;
  category: 'work' | 'personal' | 'shopping' | 'health' | 'other';
  priority: 'low' | 'medium' | 'high' | 'urgent';
  tags: string[];
}

class AITaskSuggestions {
  private taskPatterns = [
    // Work patterns
    { 
      keywords: ['meeting', 'call', 'conference', 'presentation', 'demo'],
      category: 'work' as const,
      priority: 'high' as const,
      tags: ['meeting', 'professional']
    },
    {
      keywords: ['report', 'document', 'proposal', 'write', 'draft'],
      category: 'work' as const,
      priority: 'medium' as const,
      tags: ['writing', 'documentation']
    },
    {
      keywords: ['code', 'develop', 'bug', 'fix', 'feature', 'programming'],
      category: 'work' as const,
      priority: 'high' as const,
      tags: ['development', 'coding']
    },
    
    // Personal patterns
    {
      keywords: ['exercise', 'workout', 'gym', 'run', 'fitness'],
      category: 'health' as const,
      priority: 'medium' as const,
      tags: ['health', 'fitness']
    },
    {
      keywords: ['buy', 'purchase', 'shop', 'get', 'pick up'],
      category: 'shopping' as const,
      priority: 'low' as const,
      tags: ['shopping', 'errands']
    },
    {
      keywords: ['doctor', 'appointment', 'medical', 'checkup', 'dentist'],
      category: 'health' as const,
      priority: 'high' as const,
      tags: ['health', 'appointment']
    },
    {
      keywords: ['family', 'friend', 'birthday', 'anniversary', 'celebration'],
      category: 'personal' as const,
      priority: 'medium' as const,
      tags: ['personal', 'social']
    }
  ];

  private responses = [
    "I'd be happy to help you organize that task! Here are some suggestions based on what you've shared.",
    "Great question! Let me provide some insights to help you manage your tasks more effectively.",
    "Based on your task patterns, here are some recommendations to boost your productivity.",
    "I can help you prioritize and organize your work. Here's what I suggest:",
    "Let me share some AI-powered insights to help you stay on top of your tasks.",
  ];

  generateTaskSuggestion(title: string): Promise<string> {
    return new Promise(async (resolve) => {
      try {
        const suggestion = await tasksAPI.getSuggestion(title);
        resolve(JSON.stringify(suggestion));
      } catch (error) {
        // Fallback to local suggestion
        setTimeout(() => {
          const lowerTitle = title.toLowerCase();
          
          // Find matching pattern
          const matchedPattern = this.taskPatterns.find(pattern =>
            pattern.keywords.some(keyword => lowerTitle.includes(keyword))
          );

          if (matchedPattern) {
            const suggestion: TaskSuggestion = {
              description: this.generateDescription(title, matchedPattern),
              category: matchedPattern.category,
              priority: matchedPattern.priority,
              tags: matchedPattern.tags
            };
            
            resolve(JSON.stringify(suggestion));
          } else {
            // Generic suggestion
            resolve(`Consider breaking down "${title}" into smaller, actionable steps. This will help you track progress more effectively and maintain momentum.`);
          }
        }, 1500);
      }
    });
  }

  private generateDescription(title: string, pattern: any): string {
    const descriptions = {
      work: [
        `This looks like an important work task. Consider setting a specific deadline and breaking it into smaller milestones.`,
        `Professional task identified. Make sure to allocate sufficient time and resources for completion.`,
        `Work-related item detected. Consider scheduling this during your most productive hours.`
      ],
      health: [
        `Health is wealth! This task contributes to your overall well-being. Consider making it a regular habit.`,
        `Great focus on health. Consider scheduling this at a consistent time to build a routine.`,
        `Health-related task identified. Remember to track your progress and celebrate small wins.`
      ],
      shopping: [
        `Shopping task detected. Consider creating a list to make your trip more efficient.`,
        `Looks like an errand. Try grouping similar tasks together to save time.`,
        `Shopping item identified. Consider checking for deals or alternatives before purchasing.`
      ],
      personal: [
        `Personal task identified. These often contribute significantly to life satisfaction and relationships.`,
        `This seems important for your personal life. Consider the impact on your relationships and well-being.`,
        `Personal matter detected. Make sure to give this the attention it deserves.`
      ],
      other: [
        `Task categorized as general. Consider adding more specific details to help with prioritization.`,
        `General task identified. Break this down into specific, actionable steps for better results.`
      ]
    };

    const categoryDescriptions = descriptions[pattern.category] || descriptions.other;
    return categoryDescriptions[Math.floor(Math.random() * categoryDescriptions.length)];
  }

  getChatResponse(message: string): Promise<string> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const lowerMessage = message.toLowerCase();
        
        if (lowerMessage.includes('priority') || lowerMessage.includes('prioritize')) {
          resolve("For effective prioritization, I recommend the Eisenhower Matrix: 1) Urgent + Important = Do first, 2) Important + Not urgent = Schedule, 3) Urgent + Not important = Delegate, 4) Neither = Eliminate. Would you like me to help categorize your specific tasks?");
        } else if (lowerMessage.includes('organize') || lowerMessage.includes('organization')) {
          resolve("Here are some organization tips: 1) Use categories to group similar tasks, 2) Set realistic deadlines, 3) Break large tasks into smaller steps, 4) Use tags for easy filtering, 5) Review and adjust priorities regularly. What specific area would you like help organizing?");
        } else if (lowerMessage.includes('productive') || lowerMessage.includes('productivity')) {
          resolve("To boost productivity: 1) Time-block your calendar, 2) Use the 2-minute rule (if it takes less than 2 minutes, do it now), 3) Batch similar tasks together, 4) Take regular breaks, 5) Eliminate distractions. Which productivity challenge are you facing?");
        } else if (lowerMessage.includes('stress') || lowerMessage.includes('overwhelmed')) {
          resolve("Feeling overwhelmed is normal! Try this: 1) Do a brain dump - write everything down, 2) Prioritize using urgent/important criteria, 3) Start with quick wins, 4) Break big tasks into smaller steps, 5) Remember to breathe and take breaks. You've got this! 💪");
        } else if (lowerMessage.includes('time') || lowerMessage.includes('schedule')) {
          resolve("Time management is key! Consider: 1) Time-blocking for focused work, 2) Using the Pomodoro Technique (25 min work, 5 min break), 3) Scheduling buffer time between tasks, 4) Identifying your peak energy hours, 5) Learning to say no to non-essential commitments.");
        } else if (lowerMessage.includes('habit') || lowerMessage.includes('routine')) {
          resolve("Building good habits: 1) Start small (2-minute version), 2) Stack new habits with existing ones, 3) Track your progress, 4) Celebrate small wins, 5) Be consistent, not perfect. What habit are you trying to build?");
        } else {
          const randomResponse = this.responses[Math.floor(Math.random() * this.responses.length)];
          resolve(`${randomResponse} Remember, consistency beats perfection! Focus on making steady progress rather than trying to do everything at once. What specific area would you like to explore further?`);
        }
      }, 1000 + Math.random() * 1000);
    });
  }
}

export const aiSuggestions = new AITaskSuggestions();