import React from 'react';
import { Plus, Brain, Sparkles } from 'lucide-react';
import './EmptyState.css';

const EmptyState: React.FC = () => {
  return (
    <div className="empty-state">
      <div className="empty-state-content">
        <div className="empty-state-icon">
          <Brain size={64} />
          <Sparkles className="sparkle-1" size={24} />
          <Sparkles className="sparkle-2" size={16} />
        </div>
        
        <h3>No tasks yet</h3>
        <p>Start your productivity journey by creating your first task with AI assistance!</p>
        
        <div className="empty-state-suggestions">
          <div className="suggestion-item">
            <Plus size={20} />
            <span>Click "Add Task" to get started</span>
          </div>
          <div className="suggestion-item">
            <Brain size={20} />
            <span>Let AI help you organize and prioritize</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmptyState;