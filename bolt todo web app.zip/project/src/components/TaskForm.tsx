import React, { useState } from 'react';
import { X, Brain, Sparkles } from 'lucide-react';
import { useTaskContext, Task } from '../contexts/TaskContext';
import { aiSuggestions } from '../utils/aiSuggestions';
import './TaskForm.css';

interface TaskFormProps {
  task?: Task;
  onClose: () => void;
}

const TaskForm: React.FC<TaskFormProps> = ({ task, onClose }) => {
  const { dispatch, createTask, updateTask } = useTaskContext();
  const [formData, setFormData] = useState({
    title: task?.title || '',
    description: task?.description || '',
    category: task?.category || 'other' as const,
    priority: task?.priority || 'medium' as const,
    dueDate: task?.dueDate || '',
    tags: task?.tags.join(', ') || '',
  });
  
  const [aiSuggestion, setAiSuggestion] = useState<string>('');
  const [isGeneratingSuggestion, setIsGeneratingSuggestion] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const taskData = {
      ...formData,
      tags: formData.tags.split(',').map(tag => tag.trim()).filter(Boolean),
    };

    try {
      if (task) {
        await updateTask(task.id, taskData);
      } else {
        await createTask({ ...taskData, completed: false });
      }
      onClose();
    } catch (error) {
      console.error('Failed to save task:', error);
      // You could show an error message to the user here
    }
  };

  const generateAISuggestion = async () => {
    if (!formData.title.trim()) return;
    
    setIsGeneratingSuggestion(true);
    try {
      const suggestion = await aiSuggestions.generateTaskSuggestion(formData.title);
      setAiSuggestion(suggestion);
    } catch (error) {
      console.error('Failed to generate AI suggestion:', error);
    } finally {
      setIsGeneratingSuggestion(false);
    }
  };

  const applyAISuggestion = () => {
    if (!aiSuggestion) return;
    
    try {
      const suggestion = JSON.parse(aiSuggestion);
      setFormData(prev => ({
        ...prev,
        description: suggestion.description || prev.description,
        category: suggestion.category || prev.category,
        priority: suggestion.priority || prev.priority,
        tags: suggestion.tags ? suggestion.tags.join(', ') : prev.tags,
      }));
      setAiSuggestion('');
    } catch (error) {
      // If parsing fails, treat as plain text description
      setFormData(prev => ({
        ...prev,
        description: aiSuggestion,
      }));
      setAiSuggestion('');
    }
  };

  return (
    <div className="task-form-overlay">
      <div className="task-form-container">
        <div className="task-form-header">
          <h2>{task ? 'Edit Task' : 'Create New Task'}</h2>
          <button onClick={onClose} className="close-btn">
            <X />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="task-form">
          <div className="form-group">
            <label htmlFor="title">Task Title</label>
            <div className="title-input-group">
              <input
                type="text"
                id="title"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Enter task title..."
                required
              />
              <button
                type="button"
                onClick={generateAISuggestion}
                disabled={!formData.title.trim() || isGeneratingSuggestion}
                className="ai-suggest-btn"
                title="Get AI suggestions"
              >
                {isGeneratingSuggestion ? (
                  <div className="spinner" />
                ) : (
                  <Brain size={18} />
                )}
              </button>
            </div>
          </div>

          {aiSuggestion && (
            <div className="ai-suggestion">
              <div className="ai-suggestion-header">
                <Sparkles size={16} />
                <span>AI Suggestion</span>
                <button
                  type="button"
                  onClick={applyAISuggestion}
                  className="apply-suggestion-btn"
                >
                  Apply
                </button>
              </div>
              <div className="ai-suggestion-content">
                {aiSuggestion}
              </div>
            </div>
          )}

          <div className="form-group">
            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              placeholder="Add task description..."
              rows={3}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="category">Category</label>
              <select
                id="category"
                value={formData.category}
                onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value as any }))}
              >
                <option value="work">💼 Work</option>
                <option value="personal">👤 Personal</option>
                <option value="shopping">🛒 Shopping</option>
                <option value="health">🏥 Health</option>
                <option value="other">📝 Other</option>
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="priority">Priority</label>
              <select
                id="priority"
                value={formData.priority}
                onChange={(e) => setFormData(prev => ({ ...prev, priority: e.target.value as any }))}
              >
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="dueDate">Due Date</label>
            <input
              type="date"
              id="dueDate"
              value={formData.dueDate}
              onChange={(e) => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
            />
          </div>

          <div className="form-group">
            <label htmlFor="tags">Tags</label>
            <input
              type="text"
              id="tags"
              value={formData.tags}
              onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
              placeholder="Enter tags separated by commas..."
            />
          </div>

          <div className="form-actions">
            <button type="button" onClick={onClose} className="cancel-btn">
              Cancel
            </button>
            <button type="submit" className="submit-btn">
              {task ? 'Update Task' : 'Create Task'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default TaskForm;