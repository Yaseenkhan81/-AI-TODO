import React, { useState } from 'react';
import { Search, Plus, Moon, Sun, Brain, LogOut } from 'lucide-react';
import { useTaskContext } from '../contexts/TaskContext';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import TaskForm from './TaskForm';
import './Header.css';

const Header: React.FC = () => {
  const { state, dispatch } = useTaskContext();
  const { isDark, toggleTheme } = useTheme();
  const { user, logout } = useAuth();
  const [showTaskForm, setShowTaskForm] = useState(false);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    dispatch({ type: 'SET_SEARCH', payload: e.target.value });
  };

  return (
    <header className="header">
      <div className="header-content">
        <div className="header-left">
          <div className="logo">
            <Brain className="logo-icon" />
            <h1>AI Todo 3D</h1>
          </div>
        </div>
        
        <div className="header-center">
          <div className="search-container">
            <Search className="search-icon" />
            <input
              type="text"
              placeholder="Search tasks..."
              value={state.searchQuery}
              onChange={handleSearch}
              className="search-input"
            />
          </div>
        </div>
        
        <div className="header-right">
          <div className="user-info">
            <span>Welcome, {user?.name}</span>
          </div>
          
          <button
            onClick={toggleTheme}
            className="theme-toggle"
            title="Toggle theme"
          >
            {isDark ? <Sun /> : <Moon />}
          </button>
          
          <button
            onClick={() => setShowTaskForm(true)}
            className="add-task-btn"
            title="Add new task"
          >
            <Plus />
            <span>Add Task</span>
          </button>
          
          <button
            onClick={logout}
            className="logout-btn"
            title="Logout"
          >
            <LogOut />
          </button>
        </div>
      </div>
      
      {showTaskForm && (
        <TaskForm onClose={() => setShowTaskForm(false)} />
      )}
    </header>
  );
};

export default Header;