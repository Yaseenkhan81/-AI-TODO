import React from 'react';
import { Filter, Layers } from 'lucide-react';
import { useTaskContext } from '../contexts/TaskContext';
import './TaskFilters.css';

const TaskFilters: React.FC = () => {
  const { state, dispatch } = useTaskContext();

  const categories = [
    { value: 'all', label: 'All Categories', icon: '📁' },
    { value: 'work', label: 'Work', icon: '💼' },
    { value: 'personal', label: 'Personal', icon: '👤' },
    { value: 'shopping', label: 'Shopping', icon: '🛒' },
    { value: 'health', label: 'Health', icon: '🏥' },
    { value: 'other', label: 'Other', icon: '📝' },
  ];

  const filters = [
    { value: 'all', label: 'All Tasks' },
    { value: 'active', label: 'Active' },
    { value: 'completed', label: 'Completed' },
  ];

  return (
    <div className="task-filters">
      <div className="filter-section">
        <div className="filter-header">
          <Filter size={18} />
          <span>Status</span>
        </div>
        <div className="filter-buttons">
          {filters.map(filter => (
            <button
              key={filter.value}
              onClick={() => dispatch({ type: 'SET_FILTER', payload: filter.value as any })}
              className={`filter-btn ${state.filter === filter.value ? 'active' : ''}`}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      <div className="filter-section">
        <div className="filter-header">
          <Layers size={18} />
          <span>Category</span>
        </div>
        <div className="category-buttons">
          {categories.map(category => (
            <button
              key={category.value}
              onClick={() => dispatch({ type: 'SET_CATEGORY', payload: category.value })}
              className={`category-btn ${state.selectedCategory === category.value ? 'active' : ''}`}
            >
              <span className="category-icon">{category.icon}</span>
              <span>{category.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TaskFilters;