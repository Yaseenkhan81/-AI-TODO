import React, { useState } from 'react';
import { Clock, Calendar, Tag, Edit2, Trash2, Check, X } from 'lucide-react';
import { useTaskContext, Task } from '../contexts/TaskContext';
import TaskForm from './TaskForm';
import './TaskCard.css';

interface TaskCardProps {
  task: Task;
  index: number;
}

const TaskCard: React.FC<TaskCardProps> = ({ task, index }) => {
  const { dispatch, updateTask, deleteTask } = useTaskContext();
  const [isEditing, setIsEditing] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const priorityColors = {
    low: 'var(--priority-low)',
    medium: 'var(--priority-medium)',
    high: 'var(--priority-high)',
    urgent: 'var(--priority-urgent)',
  };

  const categoryIcons = {
    work: '💼',
    personal: '👤',
    shopping: '🛒',
    health: '🏥',
    other: '📝',
  };

  const handleToggleComplete = async () => {
    try {
      await updateTask(task.id, { completed: !task.completed });
    } catch (error) {
      console.error('Failed to toggle task:', error);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      setTimeout(async () => {
        await deleteTask(task.id);
      }, 300);
    } catch (error) {
      console.error('Failed to delete task:', error);
      setIsDeleting(false);
    }
  };

  const isOverdue = task.dueDate && new Date(task.dueDate) < new Date() && !task.completed;

  return (
    <>
      <div 
        className={`task-card ${task.completed ? 'completed' : ''} ${isDeleting ? 'deleting' : ''}`}
        style={{
          '--priority-color': priorityColors[task.priority],
          '--animation-delay': `${index * 100}ms`,
        } as React.CSSProperties}
      >
        <div className="task-card-inner">
          <div className="task-header">
            <div className="task-meta">
              <span className="category-icon">
                {categoryIcons[task.category]}
              </span>
              <span className={`priority-badge priority-${task.priority}`}>
                {task.priority}
              </span>
            </div>
            
            <div className="task-actions">
              <button
                onClick={() => setIsEditing(true)}
                className="task-action-btn edit"
                title="Edit task"
              >
                <Edit2 size={16} />
              </button>
              <button
                onClick={handleDelete}
                className="task-action-btn delete"
                title="Delete task"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </div>

          <div className="task-content">
            <h3 className="task-title">{task.title}</h3>
            {task.description && (
              <p className="task-description">{task.description}</p>
            )}
            
            {task.tags.length > 0 && (
              <div className="task-tags">
                <Tag size={14} />
                {task.tags.map((tag, i) => (
                  <span key={i} className="task-tag">
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="task-footer">
            {task.dueDate && (
              <div className={`task-due-date ${isOverdue ? 'overdue' : ''}`}>
                <Calendar size={14} />
                <span>
                  {new Date(task.dueDate).toLocaleDateString()}
                </span>
              </div>
            )}
            
            <button
              onClick={handleToggleComplete}
              className={`complete-btn ${task.completed ? 'completed' : ''}`}
              title={task.completed ? 'Mark as incomplete' : 'Mark as complete'}
            >
              {task.completed ? <X size={18} /> : <Check size={18} />}
              {task.completed ? 'Completed' : 'Complete'}
            </button>
          </div>
        </div>
        
        <div className="task-card-glow"></div>
      </div>

      {isEditing && (
        <TaskForm
          task={task}
          onClose={() => setIsEditing(false)}
        />
      )}
    </>
  );
};

export default TaskCard;