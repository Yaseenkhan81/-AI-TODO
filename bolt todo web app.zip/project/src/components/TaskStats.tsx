import React from 'react';
import { CheckCircle, Clock, AlertTriangle, TrendingUp } from 'lucide-react';
import { useTaskContext } from '../contexts/TaskContext';
import './TaskStats.css';

const TaskStats: React.FC = () => {
  const { state } = useTaskContext();

  const stats = {
    total: state.tasks.length,
    completed: state.tasks.filter(task => task.completed).length,
    active: state.tasks.filter(task => !task.completed).length,
    overdue: state.tasks.filter(task => 
      task.dueDate && 
      new Date(task.dueDate) < new Date() && 
      !task.completed
    ).length,
  };

  const completionRate = stats.total > 0 ? (stats.completed / stats.total) * 100 : 0;

  const statItems = [
    {
      icon: TrendingUp,
      label: 'Total Tasks',
      value: stats.total,
      color: '#6366f1',
      bgColor: 'rgba(99, 102, 241, 0.1)',
    },
    {
      icon: CheckCircle,
      label: 'Completed',
      value: stats.completed,
      color: '#10b981',
      bgColor: 'rgba(16, 185, 129, 0.1)',
    },
    {
      icon: Clock,
      label: 'Active',
      value: stats.active,
      color: '#f59e0b',
      bgColor: 'rgba(245, 158, 11, 0.1)',
    },
    {
      icon: AlertTriangle,
      label: 'Overdue',
      value: stats.overdue,
      color: '#ef4444',
      bgColor: 'rgba(239, 68, 68, 0.1)',
    },
  ];

  return (
    <div className="task-stats">
      <div className="stats-header">
        <h3>Task Overview</h3>
        <div className="completion-rate">
          <div className="completion-circle">
            <svg viewBox="0 0 36 36" className="circular-chart">
              <path
                className="circle-bg"
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className="circle"
                strokeDasharray={`${completionRate}, 100`}
                d="M18 2.0845
                  a 15.9155 15.9155 0 0 1 0 31.831
                  a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="percentage">{Math.round(completionRate)}%</div>
          </div>
        </div>
      </div>

      <div className="stats-grid">
        {statItems.map((item) => {
          const Icon = item.icon;
          return (
            <div key={item.label} className="stat-item">
              <div 
                className="stat-icon"
                style={{ 
                  color: item.color,
                  backgroundColor: item.bgColor 
                }}
              >
                <Icon size={20} />
              </div>
              <div className="stat-content">
                <div className="stat-value">{item.value}</div>
                <div className="stat-label">{item.label}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TaskStats;