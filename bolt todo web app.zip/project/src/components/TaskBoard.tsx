import React, { useMemo } from 'react';
import { useTaskContext } from '../contexts/TaskContext';
import TaskCard from './TaskCard';
import TaskFilters from './TaskFilters';
import EmptyState from './EmptyState';
import './TaskBoard.css';

const TaskBoard: React.FC = () => {
  const { state } = useTaskContext();

  const filteredTasks = useMemo(() => {
    let filtered = state.tasks;

    // Filter by completion status
    if (state.filter === 'active') {
      filtered = filtered.filter(task => !task.completed);
    } else if (state.filter === 'completed') {
      filtered = filtered.filter(task => task.completed);
    }

    // Filter by category
    if (state.selectedCategory !== 'all') {
      filtered = filtered.filter(task => task.category === state.selectedCategory);
    }

    // Filter by search query
    if (state.searchQuery) {
      const query = state.searchQuery.toLowerCase();
      filtered = filtered.filter(task =>
        task.title.toLowerCase().includes(query) ||
        task.description.toLowerCase().includes(query) ||
        task.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }

    return filtered;
  }, [state.tasks, state.filter, state.selectedCategory, state.searchQuery]);

  return (
    <div className="task-board">
      <TaskFilters />
      
      <div className="task-grid-container">
        {filteredTasks.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="task-grid">
            {filteredTasks.map((task, index) => (
              <TaskCard 
                key={task.id} 
                task={task} 
                index={index}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default TaskBoard;